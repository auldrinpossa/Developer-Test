﻿using Group288.Entities;
using Group288.Models;
using System.Collections.Generic;

namespace Group288.Services
{
    /// <summary>
    /// IProductService
    /// </summary>
    public interface ICartService
    {
        /// <summary>
        /// GetCartProds
        /// </summary>
        /// <returns>List of cart products</returns>
        List<Cart> GetCartProds(int UserId);
       

        /// <summary>
        /// AddProduct
        /// </summary>
        /// <param name="product">productModel</param>
        bool AddToCart(ProductModel productModel);

        /// <summary>
        /// UpdateProduct
        /// </summary>
        /// <param name="product">productModel</param>
        int UpdateCart(ProductModel product);

        /// <summary>
        /// GetCartCount
        /// </summary>
        /// <returns></returns>
        int GetCartCount();
    }
}
