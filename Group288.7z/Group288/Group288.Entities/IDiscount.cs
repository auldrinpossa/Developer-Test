﻿namespace Group288.Entities
{
    /// <summary>
    /// IDiscount
    /// </summary>
    public interface IDiscount
    {
        double ApplyDiscount();        
    }
}
