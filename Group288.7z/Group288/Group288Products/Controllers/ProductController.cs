﻿using Group288.Entities;
using Group288.Models;
using Group288.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Group288Products.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;
        private readonly ICartService _cartService;
        public ProductController(IProductService productService, ICartService cartService)
        {            
            _productService = productService;
            _cartService = cartService;
        }

        [HttpGet]
        public List<ProductModel> GetProducts()
        {   var products = _productService.ProductList();
            return products;
        }

        public IActionResult Index()
        {  var products = _productService.ProductList();
            var cartcount = _cartService.GetCartCount();
            ViewBag.CartCount = cartcount;
            return View(products);
        }

        [HttpGet]
        public IActionResult View(int id)
        {
            var product = _productService.GetProductById(id);
            var attrList = _productService.GetProductAttributes(id);
            product.AttributeList = attrList;
            ViewBag.AttrList = attrList;
            var cartcount = _cartService.GetCartCount();
            ViewBag.CartCount = cartcount;
            return View(product);
        }

        [HttpGet]
        public IActionResult ViewCart()
        {  var productList = _cartService.GetCartProds(LoggedInUser.Id).ToList();           
            return View(productList);
        }

        [HttpPost]
        public int UpdateCart(int prodId)
        {  int cartCount=0;
            ProductModel product = new ProductModel();
            if (ModelState.IsValid)
            {  try
                {
                    product = _productService.GetProductById(prodId);
                    if (product != null)
                    {  
                        cartCount = _cartService.UpdateCart(product);
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Something went wrong {ex.Message}");
                }
            }
            ModelState.AddModelError(string.Empty, $"Something went wrong, invalid model");
            return cartCount;
        }

   
        public IActionResult AddDiscount(double total, string promo, string special)
        {            
            if (ModelState.IsValid)
            {
                try
                {
                    double PromoDisc=0;
                    double SpecialdDisc=0;
                    double fAmount = 0;
                    if(promo=="true")
                    {
                        PromoCodeDiscount pDiscount = new PromoCodeDiscount(total);
                        PromoDisc = pDiscount.ApplyDiscount();
                    }
                    if(special=="true")
                    {
                        SpecialDiscount sDiscount = new SpecialDiscount(total);
                        SpecialdDisc = sDiscount.ApplyDiscount();
                    }
                    fAmount = total - PromoDisc - SpecialdDisc;

                    return new JsonResult(new { promoDiscount = PromoDisc, specialDiscount = SpecialdDisc, finalAmount=fAmount });

                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Something went wrong {ex.Message}");
                }
            }
            ModelState.AddModelError(string.Empty, $"Something went wrong, invalid model");
            return  new JsonResult(new { PromoDiscount = 0, SpecialDiscount = 0 }); ;
        }
    }
}
