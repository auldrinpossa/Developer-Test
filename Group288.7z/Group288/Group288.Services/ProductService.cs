﻿using Group288.Entities;
using Group288.Models;
using Group288.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace Group288.Services
{
    public class ProductService : IProductService
    {
        IProductRepository _productRepository;
        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        /// <summary>
        /// GetProducts
        /// </summary>
        /// <returns>List of products</returns>
        public List<ProductModel> ProductList()
        {
           var plist = _productRepository.GetProducts();
            List<ProductModel> products = new List<ProductModel>();

            foreach (var item in plist)
            {
                var productModel = new ProductModel();
                productModel.ProductId = item.ProductId;
                productModel.ImagePath = item.ImagePath;
                productModel.Name = item.Name;
                productModel.Description = item.Description;
                productModel.Price = item.Price;
                products.Add(productModel);
            }

            return products;
        }

        public ProductModel GetProductById(int productId)
        {
            var prod= _productRepository.GetProductById(productId);
            var productModel = new ProductModel();
            productModel.ProductId = prod.ProductId;
            productModel.ImagePath = prod.ImagePath;
            productModel.Name = prod.Name;
            productModel.Description = prod.Description;
            productModel.Price = prod.Price;

            return productModel;
        }

        /// <summary>
        /// GetProductAttributes
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public List<ProdAttribute> GetProductAttributes(int productId)
        {
           return _productRepository.GetProductAttributes(productId);
            
        }


    }
}
