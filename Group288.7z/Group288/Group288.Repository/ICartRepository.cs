﻿using Group288.Entities;
using System;
using System.Collections.Generic;

namespace Group288.Repository
{
    public interface ICartRepository
    {
        ///// <summary>
        ///// GetProducts
        ///// </summary>
        ///// <returns>List of products</returns>
        //List<Product> GetProducts();

        /// <summary>
        /// GetCartProds
        /// </summary>
        /// <returns>List of cart products</returns>
        List<Cart> GetCartProds(int UserId);

        //public List<ProdAttribute> GetProductAttributes(int productId);

        /// <summary>
        /// AddProduct
        /// </summary>
        /// <param name="product">product</param>
        bool AddToCart(Product product);

        /// <summary>
        /// UpdateProduct
        /// </summary>
        /// <param name="product">product</param>
        int UpdateCart(Product product);

        /// <summary>
        /// GetCartCount
        /// </summary>
        /// <returns></returns>
        int GetCartCount();

        
    }
}
