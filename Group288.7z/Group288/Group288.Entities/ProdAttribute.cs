﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Group288.Entities
{
    /// <summary>
    /// ProdAttribute
    /// </summary>
    public class ProdAttribute
    {
        [Key]
        public int AttributeId { get; set; }
        public int ProductId { get; set; }
        public string Name { get; set; }
        public int Code { get; set; }
        public string Description { get; set; }
        public int Order { get; set; }
        public int Status { get; set; }


    }
}
