﻿namespace Group288.Entities
{
    public class PromoCodeDiscount : IDiscount
    {
        private readonly double _amount;
        public PromoCodeDiscount(double amount)
        {
            _amount = amount;
        }
        public double ApplyDiscount()
        {
            return _amount * 0.05;
        }
    }
}
