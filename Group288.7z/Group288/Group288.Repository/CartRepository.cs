﻿using Group288.Entities;
using Group288.Repository.EFCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Group288.Repository
{
    public class CartRepository : ICartRepository
    {
        private readonly ProductDBContext _context;

        /// <summary>
        /// CartRepository
        /// </summary>
        /// <param name="context"></param>
        public CartRepository(ProductDBContext context)
        {   _context = context;
        }

        /// <summary>
        /// GetCartProds
        /// </summary>
        /// <returns></returns>
        public List<Cart> GetCartProds(int UserId)
        { return _context.Cart.Where(x => x.UserId == UserId).ToList();
        }

        /// <summary>
        /// AddProduct
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool AddToCart(Product product)
        {    _context.Add(product);
             _context.SaveChangesAsync();  
            return true;
        }

        /// <summary>
        /// UpdateCart
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public int UpdateCart(Product product)
        {   var cartProduct = _context.Cart.Where(x => x.ProdId == product.ProductId && x.UserId==1).FirstOrDefault();
            if (cartProduct != null)
            {
                cartProduct.Qty = cartProduct.Qty + 1;
                cartProduct.Amount = (double) product.Price * cartProduct.Qty;
                _context.SaveChangesAsync();
            }
            else
            {  Cart cart = new Cart{UserId=1, ProdId=product.ProductId,Name=product.Name,Qty=1,price=product.Price,Amount= product.Price };
                _context.Cart.Add(cart);
                _context.SaveChangesAsync();
            }
            return _context.Cart.Count();
        }

        /// <summary>
        /// GetCartCount
        /// </summary>
        /// <returns></returns>
        public int GetCartCount()
        {   return _context.Cart.Count();
        }
        
    }
}
