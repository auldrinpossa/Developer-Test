using Group288.Repository.EFCore;
using Group288.UI;
using Group288Products.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Group288Products
{
    public class Program
    {
        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args">arguments parameter</param>
        public static void Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();

            using (var scope = host.Services.CreateScope())
            {
                // Get the instance of ProductDBContext in our services layer
                var services = scope.ServiceProvider;
                var context = services.GetRequiredService<ProductDBContext>();

                // Call the Seed to create sample data
                Seed.Initialize(services);
            }

            host.Run();

        }

        /// <summary>
        /// Create Host Builder 
        /// </summary>
        /// <param name="args">arguments parameter</param>
        /// <returns>IHostBuilder</returns>
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
