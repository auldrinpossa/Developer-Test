﻿using System;

namespace Gryas.Common
{
    /// <summary>
    /// Common Code To Do
    /// </summary>
    public class Class1
    {
    }
}
