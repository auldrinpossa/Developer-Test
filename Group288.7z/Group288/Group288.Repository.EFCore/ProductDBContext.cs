﻿using Group288.Entities;
using Microsoft.EntityFrameworkCore;

namespace Group288.Repository.EFCore
{
    /// <summary>
    /// ProductDBContext
    /// </summary>
    public class ProductDBContext: DbContext
    {
        /// <summary>
        /// ProductDBContext
        /// </summary>
        /// <param name="options">options</param>
        public ProductDBContext(DbContextOptions options):base(options)
        {

        }
        /// <summary>
        /// DbSet Products
        /// </summary>
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Category { get; set; }
        public DbSet<ProdAttribute> ProdAttribute { get; set; }
        public DbSet<Cart> Cart { get; set; }

        public DbSet<User> User { get; set; }

    }
}
