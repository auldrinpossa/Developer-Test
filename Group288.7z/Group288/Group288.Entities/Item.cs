﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Group288.Entities
{
    /// <summary>
    /// Item
    /// </summary>
    public class Item
    {
        [ForeignKey("Product")]
        public int ProdId { get; set; }
        [ForeignKey("ProdAttribute")]
        public int AttributeId { get; set; }
        public decimal? Price { get; set; }
        public string Image { get; set; }

    }
}
