﻿using Group288.Entities;
using Group288.Repository.EFCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Group288.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductDBContext _context;
        public ProductRepository(ProductDBContext context)
        {   _context = context;
        }
        public List<Product> GetProducts()
        {           return _context.Products.ToList();
        }
       
        public List<ProdAttribute> GetProductAttributes(int productId)
        { return _context.ProdAttribute.Where(x => x.ProductId == productId).ToList();
        }

        public Product GetProductById(int productId)
        {
            return _context.Products.Where(x => x.ProductId == productId).FirstOrDefault();
        }
       
        
    }
}
