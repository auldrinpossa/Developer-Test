﻿using Group288.Entities;
using Group288.Repository.EFCore;
using Group288Products.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace Group288.UI
{
    /// <summary>
    /// DataGenerator class to generate product data
    /// </summary>
    public class Seed
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
        using (var context = new ProductDBContext(serviceProvider.GetRequiredService<DbContextOptions<ProductDBContext>>()))
        {
            // Look for any board games.
            if (context.Products.Any())
            {
                return;   // Data was already seeded
            }

            context.Products.AddRange(
                new Product
                {
                    ProductId = 1,
                    ImagePath="XXXX",
                    Name = "TShirt",
                    Description = "Polo TShirt",
                    CategoryId = 1,
                    Price = 400
                },
                new Product
                {
                    ProductId = 2,
                    ImagePath = "XXXX",
                    Name = "TShirt",
                    Description = "Test TShirt",
                    CategoryId = 1,
                    Price = 200
                },
                new Product
                {
                    ProductId = 3,
                    ImagePath = "XXXX",
                    Name = "Jeans",
                    Description = "Lavis Jeans",
                    CategoryId = 2,
                    Price = 4000
                },
                new Product
                {
                    ProductId = 4,
                    ImagePath = "XXXX",
                    Name = "Jeans",
                    Description = "Wall Jeans",
                    CategoryId = 2,
                    Price = 1500
                });

                context.Category.AddRange(
                new Category
                {
                    CategoryId = 1,
                    CategoryCode = "Jeans",
                    CategoryName="Jeans"
                },
                new Category
                {
                    CategoryId = 2,
                    CategoryCode = "TShirt",
                    CategoryName = "TShirt"
                });

                context.ProdAttribute.AddRange(
                new ProdAttribute
                {
                    AttributeId = 1,
                    ProductId=1,                    
                    Name = "Color",
                    Code = 1,
                    Description="Red",
                    Order=1,
                    Status=1
                },
                new ProdAttribute
                {
                    AttributeId = 2,
                    ProductId = 1,
                    Name = "Color",
                    Code = 2,
                    Description = "Blue",
                    Order = 2,
                    Status = 1
                },
                new ProdAttribute
                {
                    AttributeId = 3,
                    ProductId = 1,
                    Name = "Size",
                    Code = 1,
                    Description = "Small",
                    Order = 1,
                    Status = 1
                },
                new ProdAttribute
                {
                    AttributeId = 4,
                    ProductId = 1,
                    Name = "Size",
                    Code = 2,
                    Description = "Medium",
                    Order = 2,
                    Status = 1
                },
                new ProdAttribute
                {
                    AttributeId = 5,
                    ProductId = 1,
                    Name = "Size",
                    Code = 3,
                    Description = "Large",
                    Order = 3,
                    Status = 1
                },
                new ProdAttribute
                {
                    AttributeId = 6,
                    ProductId = 2,
                    Name = "Size",
                    Code = 2,
                    Description = "XL",
                    Order = 2,
                    Status = 1
                },
                new ProdAttribute
                {
                    AttributeId = 7,
                    ProductId = 2,
                    Name = "Size",
                    Code = 2,
                    Description = "XXL",
                    Order = 2,
                    Status = 1
                },
                new ProdAttribute
                {
                    AttributeId = 8,
                    ProductId = 3,
                    Name = "Size",
                    Code = 2,
                    Description = "28 inch",
                    Order = 2,
                    Status = 1
                });

               context.User.AddRange(
               new Entities.User
               {
                   Id = 1,
                   FirstName = "Auldrin",
                   LastName = "Possa"
               });

                context.SaveChanges();
        }
    }
    }
}
