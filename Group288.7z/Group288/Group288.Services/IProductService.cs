﻿using Group288.Entities;
using Group288.Models;
using System.Collections.Generic;

namespace Group288.Services
{
    /// <summary>
    /// IProductService
    /// </summary>
    public interface IProductService
    {
        /// <summary>
        /// GetProducts
        /// </summary>
        /// <returns>List of products</returns>
        List<ProductModel> ProductList();

        /// <summary>
        /// GetProductById
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        ProductModel GetProductById(int Id);

        /// <summary>
        /// GetProductAttributes
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        List<ProdAttribute> GetProductAttributes(int productId);

        
    }
}
