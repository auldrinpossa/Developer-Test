﻿using GraysProducts.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraysProducts.Controllers
{
    public class ProductControllerOld : Controller
    {
        private readonly ProductDBContext _context;
        /// <summary>
        /// Construtor Method
        /// </summary>
        /// <param name="context"></param>
        public ProductControllerOld(ProductDBContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Gets Product List
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public List<Product> GetProducts()
        {
            return _context.Products.ToList();
        }
        
        /// <summary>
        /// Index method
        /// </summary>
        /// <returns>List of products</returns>
        public async Task<IActionResult> Index()
        {
            var products = await _context.Products.ToListAsync();
            return View(products);
        }

        /// <summary>
        /// Create Product
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Create Product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Create(Product product)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(product);
                    await _context.SaveChangesAsync();

                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Something went wrong {ex.Message}");
                }
            }

            ModelState.AddModelError(string.Empty, $"Something went wrong, invalid model");
            return View(product);
        }

        /// <summary>
        /// Edit Product by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var exist = await _context.Products.Where(x => x.Id == id).FirstOrDefaultAsync();

            return View(exist);
        }

        /// <summary>
        /// Edit Product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var exist = _context.Products.Where(x => x.Id == product.Id).FirstOrDefault();

                    if (exist != null)
                    {
                        exist.Name = product.Name;
                        exist.Color = product.Color;
                        exist.Size = product.Size;
                        exist.Price = product.Price;

                        await _context.SaveChangesAsync();

                        return RedirectToAction("Index");
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Something went wrong {ex.Message}");
                }
            }

            ModelState.AddModelError(string.Empty, $"Something went wrong, invalid model");

            return View(product);
        }

        /// <summary>
        /// Delete Product
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var exist = await _context.Products.Where(x => x.Id == id).FirstOrDefaultAsync();

            return View(exist);
        }

        /// <summary>
        /// Delete product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Delete(Product product)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var exist = _context.Products.Where(x => x.Id == product.Id).FirstOrDefault();

                    if (exist != null)
                    {
                        _context.Remove(exist);
                        await _context.SaveChangesAsync();

                        return RedirectToAction("Index");
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, $"Something went wrong {ex.Message}");
                }
            }

            ModelState.AddModelError(string.Empty, $"Something went wrong, invalid model");

            return View();
        }
    }
}
