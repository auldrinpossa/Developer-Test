﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Group288Products
{
    public static class LoggedInUser
    {
        public const int Id = 1;
        public const string FirstName = "Auldrin";
        public const string LastName = "Possa";

       
        
    }
}
