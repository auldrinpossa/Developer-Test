using Group288.Entities;
using Group288.Models;
using Group288.Repository;
using Group288.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;

namespace Group288.UnitTest
{
    [TestClass]
    public class ProductTest
    {
        [TestMethod]
        public void TestMethod_GetProductList()
        {
            var productRepository = new Mock<IProductRepository>();
            var productService = new Mock<IProductService>();

            productRepository
                .Setup(x => x.GetProducts())
                .Returns(new List<Product>
                {
                    new Product
                {
                    ProductId = 1,
                    ImagePath="Local",
                    Name = "Computer",
                    Description = "Dell",
                    CategoryId = 1,
                    Price = 4000
                },
                new Product
                {
                    ProductId = 2,
                    ImagePath="Local",
                    Name = "Jeans",
                    Description = "MacWell",
                    CategoryId = 2,
                    Price = 400
                }
                });

            var _productService = new ProductService(productRepository.Object);

            Assert.AreEqual(2, _productService.ProductList().Count);

        }

        [TestMethod]
        public void TestMethod_GetProductById()
        {

            var productRepository = new Mock<IProductRepository>();
            var productService = new Mock<IProductService>();
            var product = new Product {
                ProductId = 1,
                ImagePath = "XXXX",
                Name = "TShirt",
                Description = "Polo TShirt",
                Price = 400
            };

            productRepository
                .Setup(x => x.GetProductById(product.ProductId))
                .Returns(product);

            var productModel = GetProductObject(product);

            var _productService = new ProductService(productRepository.Object);

            var pmodel = _productService.GetProductById(productModel.ProductId);

            Assert.AreEqual(productModel.Name, pmodel.Name );

        }

        [TestMethod]
        public void TestMethod_GetProductAttributes()
        {
            var productRepository = new Mock<IProductRepository>();
            var productService = new Mock<IProductService>();
            int productId = 2;
            productRepository
                .Setup(x => x.GetProductAttributes(productId))
                .Returns(new List<ProdAttribute>
                {
                    new ProdAttribute
                {
                    AttributeId = 6,
                    ProductId = 2,
                    Name = "Size",
                    Code = 2,
                    Description = "XL",
                    Order = 2,
                    Status = 1
                },
                new ProdAttribute
                {
                     AttributeId = 7,
                    ProductId = 2,
                    Name = "Size",
                    Code = 2,
                    Description = "XXL",
                    Order = 2,
                    Status = 1
                }
                });

            var _productService = new ProductService(productRepository.Object);

            Assert.AreEqual(2, _productService.GetProductAttributes(productId).Count);

        }

        [TestMethod]
        public void TestMethod_GetCartProds()
        {
            var cartRepository = new Mock<ICartRepository>();
            var cartService = new Mock<ICartService>();
            int productId = 2;
            cartRepository
                .Setup(x => x.GetCartProds(productId))
                .Returns(new List<Cart>
                {
                    new Cart
                {
                    Id = 1,
                    UserId = 1,
                     ProdId = 2,
                    Name = "Computer",
                    Qty = 1,
                    price = 4000,
                    Amount = 4000
                }
                });

            var _cartService = new CartService(cartRepository.Object);

            Assert.AreEqual(1, _cartService.GetCartProds(productId).Count);

        }
        private ProductModel GetProductObject(Product product)
        {
            //We can use AutoMapper here
            var productModel = new ProductModel
            {
                ProductId = product.ProductId,
                ImagePath = product.ImagePath,
                Name = product.Name,
                Description = product.Description,
                CategoryId = product.CategoryId,
                Price = product.Price
            };
            return productModel;
        }
    }
}
