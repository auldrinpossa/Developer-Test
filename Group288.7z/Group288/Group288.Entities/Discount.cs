﻿namespace Group288.Entities
{
    public class Discount
    {
        public double? PromoDiscount { get; set; }
        public double? SpecialDiscount { get; set; }

    }
}
