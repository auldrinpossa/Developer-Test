﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Group288.Entities
{
    /// <summary>
    /// Product Entity
    /// </summary>
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }
        public string CategoryCode { get; set; }
        public string CategoryName { get; set; }
        
    }
}
