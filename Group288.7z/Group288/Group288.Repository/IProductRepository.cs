﻿using Group288.Entities;
using System;
using System.Collections.Generic;

namespace Group288.Repository
{
    public interface IProductRepository
    {
        /// <summary>
        /// GetProducts
        /// </summary>
        /// <returns>List of products</returns>
        List<Product> GetProducts();

        /// <summary>
        /// GetProductById
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        Product GetProductById(int productId);

        /// <summary>
        /// GetProductAttributes
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        List<ProdAttribute> GetProductAttributes(int productId);

        
    }
}
