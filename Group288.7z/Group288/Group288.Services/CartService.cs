﻿using Group288.Entities;
using Group288.Models;
using Group288.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace Group288.Services
{
    public class CartService : ICartService
    {
        ICartRepository _cartRepository;
        public CartService(ICartRepository cartRepository)
        {
            _cartRepository = cartRepository;
        }


        /// <summary>
        /// GetCartProds
        /// </summary>
        /// <returns>List of cart products</returns>
        public List<Cart> GetCartProds(int UserId)
        {
            return _cartRepository.GetCartProds(UserId);
        }
       

        /// <summary>
        /// AddProduct
        /// </summary>
        /// <param name="product">productModel</param>
        public bool AddToCart(ProductModel productModel)
        {
            var product = GetProductObject(productModel);
            return _cartRepository.AddToCart(product);
             
        }

        /// <summary>
        /// UpdateProduct
        /// </summary>
        /// <param name="product">productModel</param>
        public int UpdateCart(ProductModel productModel)
        {
            var product = GetProductObject(productModel);
            return _cartRepository.UpdateCart(product);
            
        }

        /// <summary>
        /// GetCartCount
        /// </summary>
        /// <returns></returns>
        public int GetCartCount()
        { return _cartRepository.GetCartCount(); }   

        /// <summary>
        /// GetProductObject
        /// </summary>
        /// <param name="productModel">productModel</param>
        /// <returns>product</returns>
        private Product GetProductObject(ProductModel productModel)
        {
            //We can use AutoMapper here
            var product = new Product { 
                ProductId = productModel.ProductId,
                ImagePath = productModel.ImagePath,
                Name = productModel.Name,
                Description = productModel.Description,
                Price = productModel.Price
        };
            return product;
        }
    }
}
