﻿using System.ComponentModel.DataAnnotations;

namespace Group288.Entities
{
    /// <summary>
    /// Product Entity
    /// </summary>
    public class Cart
    {
        [Key]
        public int Id { get; set; }
        public int UserId { get; set; }
        public int ProdId { get; set; }
        public string Name { get; set; }
        public int Qty { get; set; }
        public double? price { get; set; }
        public double? Amount { get; set; }

    }
}
