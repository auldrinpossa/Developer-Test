﻿using Group288.Entities;
using System.Collections.Generic;

namespace Group288.Models
{
    /// <summary>
    /// ProductModel
    /// </summary>
    public class ProductModel
    {
        public int ProductId { get; set; }
        public string ImagePath { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int CategoryId { get; set; }
        public double? Price { get; set; }

        public List<ProdAttribute> AttributeList { get; set; }
    }
}
