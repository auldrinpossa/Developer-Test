﻿namespace Group288.Entities
{
    public class SpecialDiscount : IDiscount
    {
        private readonly double _amount;
        public SpecialDiscount(double amount)
        {
            _amount = amount;
        }
        public double ApplyDiscount()
        {
            return _amount * 0.02;
        }
    }
}
